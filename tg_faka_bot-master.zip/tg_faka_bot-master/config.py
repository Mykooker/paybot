# 这是开源版本

# 易支付API地址, 末尾需要包含/
API = 'https://home.bakbak.cn/'
# 商户ID
ID = 12123
# 商户密钥
KEY = 'DZNEk2dQzKD10NCX0RwR'

# 支付成功跳转地址
JUMP_URL = "https://kangle.bakbak.cn/paysuccess.html"
# 支付超时时间(秒)
PAY_TIMEOUT = 300
# BOT API
TOKEN = '1297987814:AAG4kO2l-6wuPwoPMF7imHOJtpYAI'
# ADMIN ID
ADMIN_ID = [7442874233]

# 管理员命令
ADMIN_COMMAND_START = 'iadmin'
ADMIN_COMMAND_QUIT = 'icancel'
